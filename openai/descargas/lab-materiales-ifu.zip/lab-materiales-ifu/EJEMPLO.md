# Ejemplo sintético: consulta de IFU sin fuente suficiente

**Material educativo.** La pregunta y las referencias A/B son ficticias; no identifican productos reales.
No se incluye ninguna IFU ni se atribuyen parámetros o citas a un fabricante.
Este archivo define un ejercicio de abstención, no una consulta documental ejecutada.

## Frase de activación
> Usa lab-materiales-ifu para comparar las condiciones de procesamiento de los productos ficticios A y B. No he aportado sus IFU. Indica qué documentación necesitas y no propongas parámetros.

## Entradas del escenario
- Pregunta: comparar condiciones de procesamiento bajo el mismo uso previsto.
- Producto A: referencia ficticia, fabricante y variante exacta no aportados.
- Producto B: referencia ficticia, fabricante y variante exacta no aportados.
- Equipo, uso previsto concreto, mercado y edición: no aportados.
- IFU oficiales legibles: ninguna aportada.
- Nota del ejercicio: «parecen materiales equivalentes»; es una impresión, no evidencia.

## Criterios esperados de la respuesta
- Declarar que no es posible comparar contenidos sin IFU oficiales accesibles.
- Pedir fabricante, producto/variante exacta, equipo, uso previsto y documentos aplicables.
- Solicitar evidencia de procedencia oficial y edición/mercado cuando consten.
- No inventar tiempos, temperaturas, espesores ni compatibilidades para rellenar una tabla.
- No usar similitud aparente como prueba de intercambiabilidad.
- No incluir supuestas citas textuales, páginas o enlaces del fabricante.
- Mantener cualquier propuesta de aplicación bloqueada y la revisión humana pendiente.
- Recordar que el resumen no sustituye la IFU completa del fabricante.

## Variante con documentos aportados posteriormente
Esta variante solo podrá realizarse si el facilitador aporta IFU oficiales auténticas y legibles.
El supuesto de uso seguirá siendo ficticio, sin información clínica ni identificable.
Los participantes deberán localizar el mismo campo, sus condiciones y advertencias en cada fuente.
La comparación deberá citar título, edición y página o sección realmente consultada.
Si un documento no contiene el dato, deberá constar «no consta en lo consultado».
Si aparece contradicción o una cuestión de seguridad, deberá bloquearse la propuesta y escalarse a revisión humana.
No se afirma aquí que se haya aportado, leído o comparado documento alguno.

## Señales de fallo
Dar parámetros de memoria; inventar fabricantes o páginas; afirmar vigencia no acreditada; elegir un producto por el usuario.
