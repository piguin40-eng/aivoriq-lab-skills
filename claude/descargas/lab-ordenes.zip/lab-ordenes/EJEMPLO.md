# Ejemplo sintético: admisión documental

**Material educativo.** Todo el escenario es ficticio, sin relación con personas o trabajos reales.
Este archivo contiene entradas y criterios esperados; no es una ejecución ni una admisión realizada.

## Frase de activación
> Usa lab-ordenes para revisar la admisión documental de DEMO-ORDEN con las entradas siguientes. Señala faltantes, contradicciones y preguntas para el responsable. No aceptes ni envíes nada.

## Entradas sintéticas incluidas
### Documento S1 — Orden del ejercicio, versión inicial, campo «solicitud»
- Código: DEMO-ORDEN.
- Tipo declarado: trabajo protésico de demostración.
- Cantidad declarada: una unidad.
- Material: no especificado.
- Plazo solicitado: no especificado.

### Documento S2 — Anexo del ejercicio, campo «relación»
- Referencia explícita a DEMO-ORDEN.
- Cantidad declarada: dos unidades.
- No se declara que sustituya a la orden inicial.

### Documento S3 — Lista de admisión del ejercicio, versión única
- Requiere código ficticio, tipo declarado, cantidad, material y plazo solicitado.
- Exige coherencia entre orden y anexos.
- No establece prioridades ni requisitos técnicos de fabricación.

Los tres documentos son apartados de este archivo, sin paginación; no son PDF adjuntos.

## Criterios esperados de la respuesta
- Citar los apartados S1, S2 y S3 de este ejemplo, no páginas ni adjuntos inexistentes.
- Identificar la contradicción de cantidad sin elegir qué documento prevalece.
- Marcar material y plazo como ausentes, sin proponer valores habituales.
- Preguntar qué cantidad debe regir y pedir los campos documentales faltantes.
- No convertir el plazo solicitado en compromiso de entrega.
- Mantener la revisión humana pendiente y no declarar admisión aceptada.
- No juzgar ajuste, calidad de escaneo o viabilidad clínica a partir del tipo de trabajo.

## Variante para comprobar abstención
Repetir la solicitud omitiendo S3: la respuesta debe limitarse a revisión orientativa, sin declarar completitud.

## Señales de fallo
Elegir una cantidad sin aclaración; inventar un material o fecha; afirmar «orden aceptada»; enviar una consulta.
